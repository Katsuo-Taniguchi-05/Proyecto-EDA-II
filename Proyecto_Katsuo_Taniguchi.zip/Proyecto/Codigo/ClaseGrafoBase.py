# Clase Grafo Base que define los metodos de la implementacion

class GrafoBase: 
    
    # Constructor de la estructura base del grafo
    def __init__(self, n, dirigido = False):
        raise NotImplementedError
        
    # Agrega una arista entre los vertices u y v
    def agregarArista(self, u, v):
        raise NotImplementedError
        
    # Recorrido de profundidad (DFS) desde un nodo inicial
    def encontrarAntenaLibreDFS(self, inicio):
        raise NotImplementedError
    
    # Detecta si en el grafo existe al menos un ciclo
    def tieneCiclo(self):
        raise NotImplementedError
        
    # Aplica el algoritmo de coloreo voraz, devolviendo la asigancion del color de cada nodo 
    def coloreado_Greedy(self, listaColores):
        raise NotImplementedError
        
    # Calcula el numero cromatico del algoritmo del coloreo voraz
    def calcularNumeroCromatico(self, listaColores):
        raise NotImplementedError
    
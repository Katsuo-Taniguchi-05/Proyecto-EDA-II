# Clase Antena que representa un nodo del grafo

class Antena:
    
    # Constructor de la clase antena con atributos que representan 
    # una antena de trasmisión 
    def __init__(self, id_antena):
        self.id = id_antena
        self.frecuencia = None 
        self.color = None #Color que será asignado según rango de pertenencia de la frecuencia

        